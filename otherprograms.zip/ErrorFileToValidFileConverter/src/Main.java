import java.awt.Dimension;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

public class Main {

	/**
	 * this program converts a file with empty lines and line with the text
	 * "error" to a file without those lines
	 * 
	 * @param args
	 * @throws InterruptedException
	 */
	public static void main(String[] args) throws InterruptedException {
		List<File> files = selectInputFile();
		if (files != null && files.size() > 0) {
			JLabel label = new JLabel("Starte Konvertierung, bitte kurz warten (normalerweise max. 30 Sekunden.)");
			JOptionPane.showMessageDialog(null, label);
			for (File f : files) {
				label.setText(f.getName());
				convertFile(f);
			}

			showMessage("Abgeschlossen " + files.size() + " Dateien konvertiert.");
		} else {
			showMessage("Keine Datei oder ung�ltige Datei ausgew�hlt.\nProgramm wird beendet.");
			System.exit(0);
		}

	}

	private static void convertFile(File file) {
		if (file == null) {
			showMessage("Keine Datei oder ung�ltige Datei ausgew�hlt.\nProgramm wird beendet.");
			System.exit(0);
		}

		try {
			List<String> textLines = getLinesFromTextFile(file.getAbsolutePath());
			List<String> convertedLines = new ArrayList<>();

			for (String line : textLines) {
				if (!line.toLowerCase().contains("error")) {
					convertedLines.add(line.trim());
				}
			}
			convertedLines.forEach(line -> addToTxt(file, (file.getName().replace(".txt", "")) + ".txt", line));

		} catch (IOException e) {
			showMessage("Es ist ein Fehler beim Lesen der Datei aufgetreten.");
			showMessage("Fehlermeldung: " + e.getLocalizedMessage());
			e.printStackTrace();
			System.exit(0);
		}
	}

	private static List<File> selectInputFile() {
		String desktopPath = javax.swing.filechooser.FileSystemView.getFileSystemView().getHomeDirectory()
				.getAbsolutePath();

		JFileChooser inputFileChooser = new JFileChooser();
		inputFileChooser.setPreferredSize(new Dimension(1000, 600));
		FileNameExtensionFilter fileExtensionFilter = new FileNameExtensionFilter("text files (*.txt)", "txt");
		inputFileChooser.setFileFilter(fileExtensionFilter);
		inputFileChooser.setCurrentDirectory(new java.io.File(desktopPath));
		inputFileChooser.setDialogTitle("Eingabedatei ausw�hlen.");
		inputFileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
		inputFileChooser.setAcceptAllFileFilterUsed(false);
		inputFileChooser.setMultiSelectionEnabled(true);

		if (inputFileChooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {

			File[] files = inputFileChooser.getSelectedFiles();

			for (File f : files) {

				if (!inputFileChooser.getSelectedFile().getName().toLowerCase().endsWith(".txt")
						|| !Paths.get(inputFileChooser.getSelectedFile().getAbsolutePath()).toFile().exists()) {
					showMessage("Datei existiert nicht oder ist ein ung�ltiges Format");
				} else {
					return new ArrayList<>(Arrays.asList(inputFileChooser.getSelectedFiles()));
				}
			}

		}
		return null;
	}

	private static void showMessage(String msg) {
		JOptionPane.showMessageDialog(null, msg);
	}

	public static List<String> getLinesFromTextFile(String path) throws IOException {
		return Files.readAllLines(Paths.get(path), Charset.forName("UTF-8"));
	}

	// check filename if method is reused
	public static void addToTxt(File file, String filename, String text) {
		String path = (file.getAbsoluteFile().getParent().replace(".TXT", "") + "/valid/" + filename);
		File fileToWriteTo = new File(path);
		fileToWriteTo.getParentFile().mkdirs();
		
		try (FileWriter fw = new FileWriter(fileToWriteTo,
				true); BufferedWriter bw = new BufferedWriter(fw); PrintWriter out = new PrintWriter(bw)) {
			out.println(text);
			out.flush();
			out.close();
		} catch (Exception e) {
			showMessage("Fehler beim schreiben der Datei");
			showMessage("Fehlermeldung: " + e.getLocalizedMessage());
		}
	}

}
