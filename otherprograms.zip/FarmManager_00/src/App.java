
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

public class App extends Application{

	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		System.out.println("Application started.");
		
		
		
	
		Button btn = new Button("click me");
		btn.setOnAction(x->{
			System.out.println("clicked");
		});
		
		StackPane layout = new StackPane(btn);
		
		
        Scene scene = new Scene(layout, 400, 300);

        primaryStage.setTitle("My JavaFX Application");
        primaryStage.setScene(scene);
        primaryStage.show();
		
		
		
		
		System.out.println("Application closed.");
	}
	
	
}
