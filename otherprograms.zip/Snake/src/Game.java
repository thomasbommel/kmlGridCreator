import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JPanel;

public class Game extends JPanel implements Runnable {

	private Snake snake;

	private int lastPressedKey;
	private boolean gameRunning = true;

	public Game(Snake snake) {
		super();
		this.snake = snake;

		this.setSize(400, 400);
		this.setVisible(true);
		this.setBackground(Color.RED);

		Main.addKeyListener(new MyKeyListener() {
			@Override
			public void keyPressed(KeyEvent e) {
				lastPressedKey = e.getKeyCode();
			}
		});
	}

	@Override
	public void run() {
		while (gameRunning) {
			if (lastPressedKey != KeyEvent.VK_P) {
				int moveWidth = 10;
				int xChange = 0;
				int yChange = 0;

				if (lastPressedKey == KeyEvent.VK_UP) {
					yChange = -moveWidth;
				}
				if (lastPressedKey == KeyEvent.VK_DOWN) {
					yChange = +moveWidth;
				}
				if (lastPressedKey == KeyEvent.VK_LEFT) {
					xChange = -moveWidth;
				}
				if (lastPressedKey == KeyEvent.VK_RIGHT) {
					xChange = +moveWidth;
				}

				snake.moveForward(xChange, yChange);

				repaint();
				try {
					Thread.sleep(200);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}

	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);

		this.snake.paintComponent(g);
		g.fillRect(100, 100, 20, 20);
	}

	public void endGame() {
		this.gameRunning = false;
	}


}
