import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JFrame;
import javax.swing.WindowConstants;

public class Main {

	private static JFrame frame = new JFrame("Snake");

	public static void main(String[] args) throws InterruptedException {
		Snake snake = new Snake();
		Game game = new Game(snake);

		frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		frame.getContentPane().add(game, BorderLayout.CENTER);
		frame.getContentPane().setBackground(Color.WHITE);
		frame.pack();
		frame.setSize(400, 400);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);

		frame.addKeyListener(new MyKeyListener() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode() == KeyEvent.VK_ESCAPE){
					game.endGame();
					System.exit(0);
				}
			}
		});
		
		new Thread(game).start();
	}
	
	public static void addKeyListener(KeyListener keyl){
		frame.addKeyListener(keyl);
	}

}
