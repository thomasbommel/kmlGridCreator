import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public abstract class MyKeyListener implements KeyListener {

	@Override
	public void keyPressed(KeyEvent e){
		//do nothing
	}
	
	@Override
	public  void keyReleased(KeyEvent e){
		//do nothing
	}
	
	
	@Override
	public void keyTyped(KeyEvent e) {
		//do nothing
	}

}
