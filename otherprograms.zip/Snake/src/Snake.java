import java.awt.Graphics;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

import javax.swing.JComponent;

public class Snake extends JComponent {

	private LinkedList<BodyPart> bodyParts;
	
	private int length =3;

	

	public Snake() {
		this.bodyParts = new LinkedList<>();
		this.bodyParts.add(new BodyPart(50, 50));
	}

	public List<BodyPart> getBodyParts() {
		return bodyParts;
	}

	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		bodyParts.stream().forEach(bodyPart -> {
			g.drawRect(bodyPart.getX(), bodyPart.getY(), 10, 10);
			//System.out.println("drawn @ " + bodyPart.getX() + " " + bodyPart.getY());
		});
	}

	public BodyPart getHead() {
		return this.bodyParts.getFirst();
	}
	
	private void removeTail(){
		if(length<bodyParts.size()){
			bodyParts.removeLast();
		}
	}
	
	/**
	 * @param xChange
	 * @param yChange
	 */
	private void addNewHead(int xChange, int yChange){
		bodyParts.addFirst(new BodyPart(this.getHead().getX() + xChange, this.getHead().getY() + yChange));
	}

	/**
	 * moves the snake one 'step' forward
	 * @param xChange
	 * @param yChange
	 */
	public void moveForward(int xChange, int yChange) {
		addNewHead(xChange, yChange);
		removeTail();
	}

	public int getLength() {
		return length;
	}

	private void increaseLength(int amount) {
		this.length = length+1;
	}
	
	public void fruitWasEaten(int fruitSize){
		increaseLength(fruitSize);
	}

}
