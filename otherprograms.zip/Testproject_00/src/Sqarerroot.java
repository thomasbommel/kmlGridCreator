
public class Sqarerroot {

	public static void main(String[] args) {
		bisection(1, 2, 8, Math.pow(3, 1d / 3d));
	}

	public static double bisection(double min, double max, int precision, double goal) {
		return bisection(min, max, 0, precision, goal);
	}

	public static double bisection(double min, double max, int iterations, int precision, double goal) {
		iterations++;

		double average = (min + max) / 2;
		System.out.printf("iterations: %10d, lowerbound:  %30.20f, upperbound:  %30.20f, currentValue: %30.20f  %n", iterations,
				min, max, average);

		double diff = goal - average;

		if (checkPrecision(diff,precision)) {
			return average;
		}

		if (diff > 0) {
			return bisection(average, max, iterations, precision, goal);
		} else {
			return bisection(min, average, iterations, precision, goal);
		}
	}

	private static boolean checkPrecision(double diff,int precision) {
		return Math.abs(diff) < 1 / Math.pow(10, precision);
	}
	
	
}
