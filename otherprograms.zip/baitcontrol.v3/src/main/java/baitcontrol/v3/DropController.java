package baitcontrol.v3;

import java.util.Date;
import java.util.logging.Logger;

import de.taimos.gpsd4java.types.TPVObject;

public class DropController implements Runnable {
	private static final Logger LOGGER = Logger.getLogger(DropController.class.getName());

	private static final double SECONDS_TO_DROP = 0.1; // in seconds
	private static final double MAXIMUM_TIME_TO_DROP_IN_SECONDS = 10;

	private static final long DISTANCE_BETWEEN_DROPS = 50; // in meter
	private static boolean continueLoop = true;

	private static DropController instance;
	private static Date firstDrop;
	private TPVObject lastGPSObject;

	public static DropController getInstance() {
		if (instance == null) {
			firstDrop = new Date();
			instance = new DropController();
		}
		return instance;
	}

	public void run() {
		while (continueLoop) {
			if (lastGPSObject != null && !Double.isNaN(lastGPSObject.getLatitude()) && !Double.isNaN(lastGPSObject.getLongitude()) && !Double.isNaN(lastGPSObject.getSpeed())    ) {
				String dropDate = Utils.dateToTimeString(new Date((long) (lastGPSObject.getTimestamp() * 1000)));
				String latitude = Utils.numberToString(lastGPSObject.getLatitude());
				String longitude = Utils.numberToString(lastGPSObject.getLongitude());
				String speed = Utils.numberToString(lastGPSObject.getSpeed() * 3.6);
				long delay = getDelayForKMH(lastGPSObject.getSpeed() * 3.6);
				String delayString = Utils.numberToString(delay);

				Utils.addToTxt("drop_" + Utils.dateToTimeString(firstDrop),
						dropDate + " " + latitude + " " + longitude + " " + speed + " " + delayString);

				try {
					Thread.sleep(delay);
				} catch (InterruptedException e) {
					LOGGER.warning("DropController Thread interrupted " + e.getMessage());
				}
			}
		}
	}

	/**
	 * calculates the delay for a speed(in kmh) <b>!!! library uses m/s !!!</b>
	 * 
	 * @param speed <b>in kmh</b>
	 * @return
	 */
	public static long getDelayForKMH(double speed) {
		double delay = Math.max((long) ((DISTANCE_BETWEEN_DROPS / (speed / 3.6d) ) * 1000),
				(long) (SECONDS_TO_DROP * 1000.0));
		return (long) Math.min(delay, (long) (MAXIMUM_TIME_TO_DROP_IN_SECONDS * 1000));
	}

	public void setLastGPSObject(TPVObject obj) {
		this.lastGPSObject = obj;
	}

}
