package baitcontrol.v3;


import java.util.logging.Logger;

import de.taimos.gpsd4java.api.ObjectListener;
import de.taimos.gpsd4java.backend.GPSdEndpoint;
import de.taimos.gpsd4java.backend.ResultParser;
import de.taimos.gpsd4java.types.ATTObject;
import de.taimos.gpsd4java.types.DeviceObject;
import de.taimos.gpsd4java.types.DevicesObject;
import de.taimos.gpsd4java.types.SATObject;
import de.taimos.gpsd4java.types.SKYObject;
import de.taimos.gpsd4java.types.TPVObject;
import de.taimos.gpsd4java.types.subframes.SUBFRAMEObject;

/**
 * This class provides tests during the startup phase of GPSd4Java<br>
 * It will later be replaced by JUnit Tests
 * 
 * created: 17.01.2011
 * 
 */
public class GPSController {

	private static final String HOST = "localhost";
	private static final int PORT = 2947;

	private static final Logger log = Logger.getLogger(GPSController.class.getName());
	
	
	private static DropController dropController;

	private GPSController() {
	}

	/**
	 * @param args
	 *            the args
	 */
	public static void main(final String[] args) {
		try {
			final GPSdEndpoint ep = new GPSdEndpoint(HOST, PORT, new ResultParser());
			dropController=DropController.getInstance();

			ep.addListener(new MyObjectListener() {
				public void handleTPV(TPVObject tpv) {
					log.info(tpv.getLatitude() + "  " + tpv.getLongitude() + "  " + tpv.getSpeed() +" "+dropController.getDelayForKMH(tpv.getSpeed() * 3.6));
					System.out.println(tpv.getLatitude() + "  " + tpv.getLongitude() + "  " + tpv.getSpeed() +" "+dropController.getDelayForKMH(tpv.getSpeed() * 3.6));
					dropController.setLastGPSObject(tpv);
				}
			});

			ep.start();
			ep.watch(true, true); //never remove me !!!
			
			new Thread(dropController).start();
			log.info("dropcontroller thread started");
			Thread.sleep(10000000000l);
		} catch (final Exception e) {
			log.severe("Problem encountered: " + e.getMessage());
		}
	}
}
