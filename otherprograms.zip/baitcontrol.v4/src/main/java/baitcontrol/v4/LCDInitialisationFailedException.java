package baitcontrol.v4;

public class LCDInitialisationFailedException extends Exception {

	private static final long serialVersionUID = 1L;

	public LCDInitialisationFailedException(String msg) {
		super(msg);
	}

}
