
public class LightBarrier {

	public static void main(String[] args) {
		
		
		
		
		
		

	}

}
