import com.peertopark.java.geocalc.BoundingArea;
import com.peertopark.java.geocalc.Point;

public class ExcludedArea extends BoundingArea{

	public ExcludedArea(Point northEast, Point southWest) {
		super(northEast, southWest);
	}
	
	


	
	
}
