

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import java.util.logging.Logger;

import com.peertopark.java.geocalc.DegreeCoordinate;
import com.peertopark.java.geocalc.Point;

public class Utils {
	private static final Logger LOGGER = Logger.getLogger(Utils.class.getName());
	public static final int NUMBER_LENGTH = 25, DECIMALPLACES = 12, STRINGLENGTH = 30;
	public static final String ENDING = "; ";
	
	//private static final String desktopPath = "/home/pi/Desktop/";
	private static final String desktopPath = "/media/pi/9016-4EF8/";


	public static String stringWithFixedLength(String s, int length) {
		return String.format("%1$" + length + "s", s);
	}

	public static String stringWithFixedLength(String s) {
		return stringWithFixedLength(s, STRINGLENGTH);
	}

	public static String numberToString(double number, int length, int decimalpl) {
		return String.format("%" + length + "." + decimalpl + "f", number);
	}

	public static String numberToString(double number) {
		return numberToString(number, NUMBER_LENGTH, DECIMALPLACES);
	}

	public static String dateToString(Date date) {
		DateFormat dateFormat = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");
		dateFormat.setTimeZone(TimeZone.getTimeZone("GMT+2"));
		return dateFormat.format(date);
	}

	public static String dateToTimeString(Date date) {
		DateFormat dateFormat = new SimpleDateFormat("mm_ss_SSS");
		dateFormat.setTimeZone(TimeZone.getTimeZone("GMT+2"));
		return dateFormat.format(date);
	}

	public static void addToTxt(String filename, String text){
		try (FileWriter fw = new FileWriter(desktopPath+filename+".txt", true);
				BufferedWriter bw = new BufferedWriter(fw);
				PrintWriter out = new PrintWriter(bw)) {
			out.println(text);
			out.flush();
			LOGGER.info("added: '"+text+"' to: "+filename);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			LOGGER.severe("wasn't able to apped to txt file " + e.getMessage());
		}
	}
	
	public static List<ExcludedArea> getExcludedAreas(){
		try {
			List<String> lines = Files.readAllLines(Paths.get("/media/pi/9016-4EF8/exclude.txt"), Charset.forName("UTF-8"));
			
			List<ExcludedArea> excludedAreas = new ArrayList<>();
			lines.stream().forEach(line->{
				DegreeCoordinate northWestLat = new DegreeCoordinate(Double.parseDouble(line.substring(0, 9)));
				DegreeCoordinate northWestLng = new DegreeCoordinate(Double.parseDouble(line.substring(10, 19)));
				DegreeCoordinate southEastLat = new DegreeCoordinate(Double.parseDouble(line.substring(20, 29)));
				DegreeCoordinate southEastLng = new DegreeCoordinate(Double.parseDouble(line.substring(30, 39)));
				Point northEast = new Point(northWestLat,southEastLng);
				Point southWest = new Point(southEastLat,northWestLng);
				
				ExcludedArea excl = new ExcludedArea(northEast, southWest);
				excludedAreas.add(excl);
				System.out.println("excluded "+excl.toString());
				LOGGER.info("excluded "+excl.toString());
			});
			return excludedAreas;
		} catch (IOException e) {
			e.printStackTrace();
			return Collections.EMPTY_LIST;
		}
		
		
		
		
	}
	
	
	
	
	
	
	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
