package exclude;

import java.awt.Dimension;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

import de.micromata.opengis.kml.v_2_2_0.Document;
import de.micromata.opengis.kml.v_2_2_0.Feature;
import de.micromata.opengis.kml.v_2_2_0.Geometry;
import de.micromata.opengis.kml.v_2_2_0.Kml;
import de.micromata.opengis.kml.v_2_2_0.LineString;
import de.micromata.opengis.kml.v_2_2_0.Location;
import de.micromata.opengis.kml.v_2_2_0.Placemark;

/**
 * creates the exluce file from the kml files
 * @author Sallaberger
 *
 */
public class Main {

	private static ArrayList<String> newLines = new ArrayList<String>();

	public static void main(String[] args) throws IOException {
		long start = System.currentTimeMillis();
		
//		File folder = new File(".\\convert");
		
		File folder = selectInputDirectory();
		
		
		
		
		
		getCoordinatesFromDirectory(folder);
		//newLines.forEach(System.out::println);
		Files.write(Paths.get(folder.getAbsolutePath()+"\\exclude.txt"),newLines,Charset.defaultCharset());
		System.out.println("Finished in: "+(System.currentTimeMillis()-start)+" ms.");
	}
	
	protected static File selectInputDirectory() {
		String desktopPath = javax.swing.filechooser.FileSystemView.getFileSystemView().getHomeDirectory()
				.getAbsolutePath();

		JFileChooser inputFileChooser = new JFileChooser();
		inputFileChooser.setPreferredSize(new Dimension(1000, 600));
//		FileNameExtensionFilter fileExtensionFilter = new FileNameExtensionFilter("text files (*.txt)", "txt");
//		inputFileChooser.setFileFilter(fileExtensionFilter);
		
		
		inputFileChooser.setCurrentDirectory(new java.io.File(desktopPath));
		inputFileChooser.setDialogTitle("Ordner ausw�hlen.");
		inputFileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		inputFileChooser.setAcceptAllFileFilterUsed(false);

		if (inputFileChooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
//			if (!inputFileChooser.getSelectedFile().getName().toLowerCase().endsWith(".txt")
//					|| !Paths.get(inputFileChooser.getSelectedFile().getAbsolutePath()).toFile().exists()) {
//				JOptionPane.showMessageDialog(null, "Datei existiert nicht oder ist ein ung�ltiges Format");
//			} else {
//				return inputFileChooser.getCurrentDirectory();
//			}
			if(!inputFileChooser.getSelectedFile().isDirectory()){
				JOptionPane.showMessageDialog(null, "Es k�nnen nur gesamte Ordner konvertiert werden.");
				selectInputDirectory();
			}
			
			return inputFileChooser.getSelectedFile();
		}
		return null;
	}

	public static void getCoordinatesFromDirectory(File folder) throws IOException {
		File[] listOfFiles = folder.listFiles();

		for (int i = 0; i < listOfFiles.length; i++) {
			if (listOfFiles[i].isFile()) {
				String filename = listOfFiles[i].getName();
				// System.out.println("File " + filename);

				List<ByteArrayOutputStream> outputstreams = getKMLInputStream(
						Paths.get(folder.getAbsolutePath() + "\\" + filename));
				for (ByteArrayOutputStream out : outputstreams) {
					getCoordinatesFromKMLByteArrayOutputStream(out);
				}

			} else if (listOfFiles[i].isDirectory()) {
				// System.out.println("Directory " + listOfFiles[i].getName());
				getCoordinatesFromDirectory(listOfFiles[i]);
			}
		}
	}

	public static void getCoordinatesFromKMLByteArrayOutputStream(ByteArrayOutputStream output) throws IOException {
		ByteArrayInputStream stream = new ByteArrayInputStream(output.toByteArray());

		final Kml kml = Kml.unmarshal(stream);
		final Document doc = (Document) kml.getFeature();

		final List<Feature> features = doc.getFeature();

		final List<Placemark> placemarks = new ArrayList<Placemark>();

		for (Feature f : features) {
			placemarks.add((Placemark) f);
		}

		for (Placemark p : placemarks) {
			Geometry g = p.getGeometry();
			if (g instanceof LineString) {
				LineString l = (LineString) g;
				//System.out.println(l.getCoordinates().get(0));
				//System.out.println(l.getCoordinates().get(2));

				String coord1= l.getCoordinates().get(0).toString();
				String coord2= l.getCoordinates().get(2).toString();
				String newLine = String.format("%20.15f",Double.parseDouble(coord1.split(",")[1]));
				newLine += String.format(" %20.15f",Double.parseDouble(coord1.split(",")[0]));
				newLine += String.format(" %20.15f",Double.parseDouble(coord2.split(",")[1]));
				newLine += String.format(" %20.15f",Double.parseDouble(coord2.split(",")[0]));
				newLines.add(newLine.replace(",", "."));
			}
		}
	}

	public static List<String> getAllLinesFromTxt(Path path) throws IOException {
		Charset charset = Charset.forName("ISO-8859-1");

		List<String> lines = Files.readAllLines(path, charset);

		for (String line : lines) {
			// System.out.println(line);
		}
		return lines;
	}

	public static List<ByteArrayOutputStream> getKMLInputStream(Path filename) {
		ArrayList<ByteArrayOutputStream> outPutStreams = new ArrayList<ByteArrayOutputStream>();
		try {
			byte[] buf = new byte[1024];
			ZipInputStream zipinputstream = null;
			ZipEntry zipentry;
			zipinputstream = new ZipInputStream(new FileInputStream(filename.toFile()));

			zipentry = zipinputstream.getNextEntry();
			while (zipentry != null) {
				// for each entry to be extracted
				String entryName = zipentry.getName();
				int n;
				ByteArrayOutputStream fileoutputstream = new ByteArrayOutputStream();
				File newFile = new File(entryName);
				String directory = newFile.getParent();

				if (directory == null) {
					if (newFile.isDirectory())
						break;
				}
				String newFileName = filename + "_" + entryName;

				while ((n = zipinputstream.read(buf, 0, 1024)) > -1)
					fileoutputstream.write(buf, 0, n);

				fileoutputstream.close();
				zipinputstream.closeEntry();
				zipentry = zipinputstream.getNextEntry();
				outPutStreams.add(fileoutputstream);
			}
			zipinputstream.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return outPutStreams;
	}

	// public static String getZipFiles(Path filename) {
	// try {
	// byte[] buf = new byte[1024];
	// ZipInputStream zipinputstream = null;
	// ZipEntry zipentry;
	// zipinputstream = new ZipInputStream(new
	// FileInputStream(filename.toFile()));
	//
	// zipentry = zipinputstream.getNextEntry();
	// while (zipentry != null) {
	// // for each entry to be extracted
	// String entryName = zipentry.getName();
	// int n;
	// FileOutputStream fileoutputstream;
	// File newFile = new File(entryName);
	// String directory = newFile.getParent();
	//
	// if (directory == null) {
	// if (newFile.isDirectory())
	// break;
	// }
	// String newFileName = filename + "_" + entryName;
	// fileoutputstream = new FileOutputStream(newFileName);
	//
	// while ((n = zipinputstream.read(buf, 0, 1024)) > -1)
	// fileoutputstream.write(buf, 0, n);
	//
	// fileoutputstream.close();
	// zipinputstream.closeEntry();
	// zipentry = zipinputstream.getNextEntry();
	// return newFileName;
	// }
	// zipinputstream.close();
	// } catch (Exception e) {
	// e.printStackTrace();
	// }
	// return null;
	// }

	// public static void getCoordinatesFromKML(Path path) throws IOException {
	// List<String> lines = getAllLinesFromTxt(path);
	//
	// final Kml kml = Kml.unmarshal(path.toFile());
	// final Document doc = (Document) kml.getFeature();
	//
	// final List<Feature> features = doc.getFeature();
	//
	// final List<Placemark> placemarks = new ArrayList<Placemark>();
	//
	// for (Feature f : features) {
	// placemarks.add((Placemark) f);
	// }
	//
	// for (Placemark p : placemarks) {
	// Geometry g = p.getGeometry();
	// if (g instanceof LineString) {
	// LineString l = (LineString) g;
	// // System.out.println(l.getCoordinates().get(0));
	// // System.out.println(l.getCoordinates().get(2));
	// }
	//
	// }
	//
	// }

}
