package dev.floresgaming.game.states;

import java.awt.Graphics;

import dev.floresgaming.game.Game;
import dev.floresgaming.game.Handler;

/*
 * this is supposed to be the settings menu but i have not implemented it yet.
 */

public class SettingsState extends State {

	/*
	 * takes a handler and then passes it through to the super class
	 */
	public SettingsState(Handler handler) {
		super(handler);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see dev.floresgaming.game.states.State#tick()
	 */
	public void tick() {

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see dev.floresgaming.game.states.State#render(java.awt.Graphics)
	 */
	public void render(Graphics g) {

	}

}
