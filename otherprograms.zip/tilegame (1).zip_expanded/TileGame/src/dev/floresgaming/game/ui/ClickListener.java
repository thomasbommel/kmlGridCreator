package dev.floresgaming.game.ui;

/*
 * used to recognize clicks not to sure how it works though
 */

public interface ClickListener {
	public void onClick();
}
